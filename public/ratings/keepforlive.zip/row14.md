---
id: "14"
title: "Floral Art School"
slug: "Floral-Art-School"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['VIC']
tags: ['Elsternwick']
address: "22 Riddell Pde"
postcode: "3185"
phone: "(03) 9523 5052"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---