---
title: "Sleeps 2-4"
meta:
  title: "Best Caravans that Sleep 2-4 People | Caravans in Australia"
  description: ""
  ogtitle: "Best Caravans that Sleep 2-4 People | Caravans in Australia"
  ogdescription: ""
---
