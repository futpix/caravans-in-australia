---
title: "Sleeps 8"
meta:
  title: "Best Caravans that Sleep 8 People | Caravans in Australia"
  description: ""
  ogtitle: "Best Caravans that Sleep 8 People | Caravans in Australia"
  ogdescription: ""
---
