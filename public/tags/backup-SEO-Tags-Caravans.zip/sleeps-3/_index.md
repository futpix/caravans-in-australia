---
title: "Sleeps 3"
meta:
  title: "Best Caravans that Sleep 3 People | Caravans in Australia"
  description: ""
  ogtitle: "Best Caravans that Sleep 3 People | Caravans in Australia"
  ogdescription: ""
---
