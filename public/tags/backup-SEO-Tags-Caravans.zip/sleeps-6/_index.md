---
title: "Sleeps 6"
meta:
  title: "Best Caravans that Sleep 6 People | Caravans in Australia"
  description: ""
  ogtitle: "Best Caravans that Sleep 6 People | Caravans in Australia"
  ogdescription: ""
---
