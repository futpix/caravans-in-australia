---
title: "Sleeps 5"
meta:
  title: "Best Caravans that Sleep 5 People | Caravans in Australia"
  description: ""
  ogtitle: "Best Caravans that Sleep 5 People | Caravans in Australia"
  ogdescription: ""
---
