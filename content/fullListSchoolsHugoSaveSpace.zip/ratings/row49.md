---
id: "49"
title: "Southern Cross School K-12 Distance Education Centre"
slug: "Southern-Cross-School-K-12-Distance-Education-Centre"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['NSW']
tags: ['East Ballina']
address: "Chickiba Drv"
postcode: "2478"
phone: "(02) 6686 9112"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---