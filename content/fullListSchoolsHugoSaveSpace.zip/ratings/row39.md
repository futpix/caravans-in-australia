---
id: "39"
title: "Health & Harmony Colleges"
slug: "Health-&-Harmony-Colleges"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['QLD']
tags: ['Woolloongabba']
address: "3/ 16-36 Nile St"
postcode: "4102"
phone: "1300 131 492"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
realScore: 78
---