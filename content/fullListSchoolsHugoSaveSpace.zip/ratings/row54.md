---
id: "54"
title: "Armidale School Of Expressive Art"
slug: "Armidale-School-Of-Expressive-Art"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['ACT']
tags: ['Chisholm']
address: "8 Goodsir Pl"
postcode: "2905"
phone: "1800 352 179"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---