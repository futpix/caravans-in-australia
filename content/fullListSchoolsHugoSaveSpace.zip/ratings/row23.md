---
id: "23"
title: "University Of Tasmania"
slug: "University-Of-Tasmania"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['TAS']
tags: ['Hobart']
address: "PO Box 86"
postcode: "7001"
phone: "(03) 6226 2999"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---