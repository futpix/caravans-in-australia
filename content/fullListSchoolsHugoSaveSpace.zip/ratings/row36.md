---
id: "36"
title: "Capricornia School Of Distance Education"
slug: "Capricornia-School-Of-Distance-Education"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['QLD']
tags: ['North Rockhampton']
address: "Farm St"
postcode: "4701"
phone: "(07) 4931 4800"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---