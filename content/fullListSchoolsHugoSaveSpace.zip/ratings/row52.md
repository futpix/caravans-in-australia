---
id: "52"
title: "Queensland Institute of Natural Science"
slug: "Queensland-Institute-of-Natural-Science"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['QLD']
tags: ['Maroochydore']
address: "Suite 4 Dalton Pl"
postcode: "4558"
phone: "1800 072 050"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---