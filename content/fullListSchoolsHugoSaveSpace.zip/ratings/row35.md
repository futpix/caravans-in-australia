---
id: "35"
title: "Australian College of Journalism"
slug: "Australian-College-of-Journalism"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['NSW']
tags: ['Bondi Junction']
address: "175 Oxford St"
postcode: "2022"
phone: "(02) 9389 6499"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---