---
id: "47"
title: "Kodomo Japanese Language School"
slug: "Kodomo-Japanese-Language-School"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['NSW']
tags: ['Mosman']
address: "9 Beauty Point Rd"
postcode: "2088"
phone: "(02) 9969 9205"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---