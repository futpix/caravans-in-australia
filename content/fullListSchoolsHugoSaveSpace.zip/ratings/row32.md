---
id: "32"
title: "Professional Recognition in Distance Education"
slug: "Professional-Recognition-in-Distance-Education"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['QLD']
tags: ['Norman Park']
address: "PO Box 3056"
postcode: "4170"
phone: "(07) 3392 2077"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---