---
id: "50"
title: "Capricornia School Of Distance Education"
slug: "Capricornia-School-Of-Distance-Education"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['QLD']
tags: ['Emerald']
address: "Cnr Gladstone & Gray Sts"
postcode: "4720"
phone: "(07) 4987 4155"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---