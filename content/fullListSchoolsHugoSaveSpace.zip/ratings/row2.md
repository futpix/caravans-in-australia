---
id: "2"
title: "Virtual School For The Gifted"
slug: "Virtual-School-For-The-Gifted"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['VIC']
tags: ['Kensington']
address: ""
postcode: "3031"
phone: "(03) 9371 7446"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---