---
id: "1"
title: "Distance Education Tasmania"
slug: "Distance-Education-Tasmania"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['TAS']
tags: ['Lindisfarne']
address: "Kaoota Rd"
postcode: "7015"
phone: "(03) 6233 7786"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---