---
id: "51"
title: "Edfit"
slug: "Edfit"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['QLD']
tags: ['Loganholme']
address: "PO Box 3589"
postcode: "4129"
phone: "(07) 3287 7071"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---