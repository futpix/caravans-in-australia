---
id: "4"
title: "Distance Education Centre Victoria"
slug: "Distance-Education-Centre-Victoria"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['VIC']
tags: ['Thornbury']
address: "315 Clarendon St"
postcode: "3071"
phone: "(03) 8480 0000"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---