---
id: "21"
title: "Alice Springs School Of The Air"
slug: "Alice-Springs-School-Of-The-Air"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['NT']
tags: ['Alice Springs']
address: "80 Head St"
postcode: "870"
phone: "(08) 8951 6800"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---