---
id: "48"
title: "College Of Somatic Studies"
slug: "College-Of-Somatic-Studies"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['QLD']
tags: ['Ormeau']
address: ""
postcode: "4208"
phone: "1800 252 562"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---