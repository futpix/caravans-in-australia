---
id: "34"
title: "Christian Education Ministries Inc."
slug: "Christian-Education-Ministries-Inc."
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['QLD']
tags: ['Caboolture BC']
address: "PO Box 3101"
postcode: "4510"
phone: "(07) 3881 5744"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---