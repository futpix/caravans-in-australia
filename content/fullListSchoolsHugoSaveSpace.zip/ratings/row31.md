---
id: "31"
title: "Soul Cottage International Correspondence School of Thinking Higher by Robin Folklores"
slug: "Soul-Cottage-International-Correspondence-School-of-Thinking-Higher-by-Robin-Folklores"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['NSW']
tags: ['Umina']
address: "PO Box 3003"
postcode: "2257"
phone: "0412 488 800"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
international: "yes"
realScore: 70
---