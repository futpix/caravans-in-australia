---
id: "29"
title: "The Interior Design Academy"
slug: "The-Interior-Design-Academy"
draft: "false"
author: "Sean"
seealsolinks: "1"
section: "blog"
categories: ['NSW']
tags: ['Double Bay']
address: ""
postcode: "1360"
phone: "1800 071 100"
schoolType: "School-Correspondence"
date: "2020-11-10T22:00:09+11:00"
---